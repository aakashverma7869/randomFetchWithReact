import React from "react";

export default class FetchRandomUser extends React.Component {
  state = {
    loading: true,
    person: null
  };

  async componentDidMount() {
    const bearer = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbkBkaWdpc2hhYWxhLmNvbSIsInNjb3BlcyI6IlJPTEVfQURNSU4sUk9MRV9TVVBFUkFETUlOIiwiaWF0IjoxNjA1MTg3NjYwLCJleHAiOjE2MDUyNzQwNjB9.d7fE6Zow0gpyQ8B4d5Z6CufOPYsbe0ArF3tguh3lnn4';
    const url = "/facilities";
    await fetch(url,{
      method: 'GET',
      withCredentials: true,
      credentials: 'include',
      headers: {
          'Authorization': "Bearer "+bearer
      }
  }).then((response) => response.json())
  .then((responseJson) => {
    console.log("check1-->>"+JSON.stringify(responseJson.data));
    this.setState({ person: responseJson.data, loading: false });
  })
  .catch((error) => {
      console.error(error);
  });


  
  }

  render() {
    if (this.state.loading) {
      return <div>loading...</div>;
    }

    if (!this.state.person) {
      return <div>didn't get a person</div>;
    }

    return (
      <div> 
          <ul>
      {this.state.person.map((value, index) => {
        return <li key={index}>{value.name}</li>
      })}
    </ul>

      </div>
    );
  }
}
